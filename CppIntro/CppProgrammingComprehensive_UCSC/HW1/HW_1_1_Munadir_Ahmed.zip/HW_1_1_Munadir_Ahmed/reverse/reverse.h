/*
Author: Munadir Ahmed
Date: 4/7/18

*/

// file: reverse.h


// All includes
#ifndef REVERSE_H   
#define REVERSE_H



#include "../util/util.h"

// Declaration of class

class reverse1 {
public:
	unsigned long r(unsigned long n);
	unsigned long firstFail();
private:
};


#endif // REVERSE_H