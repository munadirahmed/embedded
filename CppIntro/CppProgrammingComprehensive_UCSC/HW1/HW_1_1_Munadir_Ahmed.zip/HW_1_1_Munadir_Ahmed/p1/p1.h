/*
Author: Munadir Ahmed
Date: 4/7/18

*/

// file: p1.h


// All includes
#ifndef P1_H   
#define P1_H



#include "../util/util.h"

// Declaration of class

class p1 {
public:
	void print_usa();
	void print_n_n2_n3();
	void a_power_b();
	void two_power_n();
	void a1(unsigned int  aMinNum, unsigned int  aMaxNum);
	void a2(unsigned int  aMinNum, unsigned int  aMaxNum);
	void a3(unsigned int  aMinNum, unsigned int  aMaxNum);
	void a4(unsigned int  aMinNum, unsigned int  aMaxNum);
private:
};


#endif // !P1_H