/*
Author: Munadir Ahmed
Date: 4/13/18

*/

// file: ninetynine.h


// All includes
#ifndef NINETYNINE_H   
#define NINETYNINE_H



#include "../util/util.h"

// Declaration of class

class ninetynine {
public:
	void ninetyninebottles();
private:
};


#endif // !NINETYNINE_H